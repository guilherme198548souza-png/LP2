using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        Double peso, altura, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Clear();
            mskbxPeso.Clear();
            mskbxResultado.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Voc� deseja sair mesmo?",
                                "Sa�da", MessageBoxButtons.YesNo
                                , MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskbxPeso.Text, out peso) || peso <= 0)
            {
                errorProvider1.SetError(mskbxPeso, "Peso inv�lido!");
                txtPesoAtual.Focus();
            }
            else
            {
                errorProvider1.Clear();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {

            if (peso == 0 || altura == 0)
            {
                MessageBox.Show("Informe peso e altura v�lidos!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            resultado = peso / (altura * altura);
            resultado = Math.Round(resultado, 1);

            mskbxResultado.Text = resultado.ToString("F1");
        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskbxAltura.Text, out altura) || altura <= 0)
            {
                errorProvider2.SetError(mskbxAltura, "Peso inv�lido!");
                txtAltura.Focus();
            }
            else
            {
                errorProvider2.Clear();
            }
        }
    }
}

