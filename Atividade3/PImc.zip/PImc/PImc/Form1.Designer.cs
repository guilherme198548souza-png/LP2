﻿namespace PImc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            txtPesoAtual = new Label();
            txtAltura = new Label();
            txtIMC = new Label();
            mskbxPeso = new MaskedTextBox();
            mskbxAltura = new MaskedTextBox();
            btnCalcular = new TextBox();
            btnLimpar = new TextBox();
            btnSair = new TextBox();
            mskbxResultado = new MaskedTextBox();
            errorProvider1 = new ErrorProvider(components);
            errorProvider2 = new ErrorProvider(components);
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider2).BeginInit();
            SuspendLayout();
            // 
            // txtPesoAtual
            // 
            txtPesoAtual.AutoSize = true;
            txtPesoAtual.Location = new Point(266, 86);
            txtPesoAtual.Name = "txtPesoAtual";
            txtPesoAtual.Size = new Size(95, 25);
            txtPesoAtual.TabIndex = 0;
            txtPesoAtual.Text = "Peso Atual";
            // 
            // txtAltura
            // 
            txtAltura.AutoSize = true;
            txtAltura.Location = new Point(302, 138);
            txtAltura.Name = "txtAltura";
            txtAltura.Size = new Size(59, 25);
            txtAltura.TabIndex = 1;
            txtAltura.Text = "Altura";
            // 
            // txtIMC
            // 
            txtIMC.AutoSize = true;
            txtIMC.Location = new Point(317, 188);
            txtIMC.Name = "txtIMC";
            txtIMC.Size = new Size(44, 25);
            txtIMC.TabIndex = 2;
            txtIMC.Text = "IMC";
            // 
            // mskbxPeso
            // 
            mskbxPeso.Location = new Point(384, 83);
            mskbxPeso.Mask = "999.00";
            mskbxPeso.Name = "mskbxPeso";
            mskbxPeso.Size = new Size(150, 31);
            mskbxPeso.TabIndex = 3;
            mskbxPeso.Validated += mskbxPeso_Validated;
            // 
            // mskbxAltura
            // 
            mskbxAltura.Location = new Point(384, 132);
            mskbxAltura.Mask = "9.00";
            mskbxAltura.Name = "mskbxAltura";
            mskbxAltura.Size = new Size(150, 31);
            mskbxAltura.TabIndex = 4;
            mskbxAltura.Validated += mskbxAltura_Validated;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(211, 239);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(150, 31);
            btnCalcular.TabIndex = 5;
            btnCalcular.Text = "Calcular";
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(400, 239);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(150, 31);
            btnLimpar.TabIndex = 6;
            btnLimpar.Text = "Limpar";
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(592, 239);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(150, 31);
            btnSair.TabIndex = 7;
            btnSair.Text = "Sair";
            btnSair.Click += btnSair_Click;
            // 
            // mskbxResultado
            // 
            mskbxResultado.Location = new Point(384, 182);
            mskbxResultado.Name = "mskbxResultado";
            mskbxResultado.ReadOnly = true;
            mskbxResultado.Size = new Size(150, 31);
            mskbxResultado.TabIndex = 8;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            errorProvider2.ContainerControl = this;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(797, 343);
            Controls.Add(mskbxResultado);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(btnCalcular);
            Controls.Add(mskbxAltura);
            Controls.Add(mskbxPeso);
            Controls.Add(txtIMC);
            Controls.Add(txtAltura);
            Controls.Add(txtPesoAtual);
            Name = "Form1";
            Text = "PImc";
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label txtPesoAtual;
        private Label txtAltura;
        private Label txtIMC;
        private MaskedTextBox mskbxPeso;
        private MaskedTextBox mskbxAltura;
        private TextBox btnCalcular;
        private TextBox btnLimpar;
        private TextBox btnSair;
        private MaskedTextBox mskbxResultado;
        private ErrorProvider errorProvider1;
        private ErrorProvider errorProvider2;
    }
}
