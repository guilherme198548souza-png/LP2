﻿namespace Pmatrizes
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnexercicio1 = new System.Windows.Forms.Button();
            this.btnexercicio2 = new System.Windows.Forms.Button();
            this.btnexercicio3 = new System.Windows.Forms.Button();
            this.btnexercicio4 = new System.Windows.Forms.Button();
            this.btnexercicio5 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnexercicio1
            // 
            this.btnexercicio1.Location = new System.Drawing.Point(184, 23);
            this.btnexercicio1.Name = "btnexercicio1";
            this.btnexercicio1.Size = new System.Drawing.Size(163, 92);
            this.btnexercicio1.TabIndex = 0;
            this.btnexercicio1.Text = "Exercício 1";
            this.btnexercicio1.UseVisualStyleBackColor = true;
            this.btnexercicio1.Click += new System.EventHandler(this.btnexercicio1_Click);
            // 
            // btnexercicio2
            // 
            this.btnexercicio2.Location = new System.Drawing.Point(394, 23);
            this.btnexercicio2.Name = "btnexercicio2";
            this.btnexercicio2.Size = new System.Drawing.Size(167, 92);
            this.btnexercicio2.TabIndex = 1;
            this.btnexercicio2.Text = "Exercício 2";
            this.btnexercicio2.UseVisualStyleBackColor = true;
            this.btnexercicio2.Click += new System.EventHandler(this.btnexercicio2_Click);
            // 
            // btnexercicio3
            // 
            this.btnexercicio3.Location = new System.Drawing.Point(184, 158);
            this.btnexercicio3.Name = "btnexercicio3";
            this.btnexercicio3.Size = new System.Drawing.Size(163, 91);
            this.btnexercicio3.TabIndex = 2;
            this.btnexercicio3.Text = "Exercício 3";
            this.btnexercicio3.UseVisualStyleBackColor = true;
            this.btnexercicio3.Click += new System.EventHandler(this.btnexercicio3_Click);
            // 
            // btnexercicio4
            // 
            this.btnexercicio4.Location = new System.Drawing.Point(394, 158);
            this.btnexercicio4.Name = "btnexercicio4";
            this.btnexercicio4.Size = new System.Drawing.Size(171, 91);
            this.btnexercicio4.TabIndex = 3;
            this.btnexercicio4.Text = "Exercício 4";
            this.btnexercicio4.UseVisualStyleBackColor = true;
            this.btnexercicio4.Click += new System.EventHandler(this.btnexercicio4_Click);
            // 
            // btnexercicio5
            // 
            this.btnexercicio5.Location = new System.Drawing.Point(289, 280);
            this.btnexercicio5.Name = "btnexercicio5";
            this.btnexercicio5.Size = new System.Drawing.Size(170, 91);
            this.btnexercicio5.TabIndex = 4;
            this.btnexercicio5.Text = "Exercício 5";
            this.btnexercicio5.UseVisualStyleBackColor = true;
            this.btnexercicio5.Click += new System.EventHandler(this.btnexercicio5_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(895, 496);
            this.Controls.Add(this.btnexercicio5);
            this.Controls.Add(this.btnexercicio4);
            this.Controls.Add(this.btnexercicio3);
            this.Controls.Add(this.btnexercicio2);
            this.Controls.Add(this.btnexercicio1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnexercicio1;
        private System.Windows.Forms.Button btnexercicio2;
        private System.Windows.Forms.Button btnexercicio3;
        private System.Windows.Forms.Button btnexercicio4;
        private System.Windows.Forms.Button btnexercicio5;
    }
}

