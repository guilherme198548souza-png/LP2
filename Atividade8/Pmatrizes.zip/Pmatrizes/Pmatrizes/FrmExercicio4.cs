﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmatrizes
{
    public partial class FrmExercicio4 : Form
    {
        public FrmExercicio4()
        {
            InitializeComponent();
        }

        private void btnexecutar_Click(object sender, EventArgs e)
        {
            string[] nome = new string[10];
            int[] comprimento = new int[10];
            string auxiliar;

            for (int i = 0; i < 10; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i + 1} nome:", "Entrada de Dados");

                if (auxiliar == "")
                {
                    MessageBox.Show("Dado inválido");
                    i--;
                }
                else
                {
                    nome[i] = auxiliar;
                    comprimento[i] = auxiliar.Replace(" ", "").Length;
                    lstbxnomes.Items.Add($"o nome:{nome[i]} tem {comprimento[i]} caracteres\n");
                }
            }
        }
            
        
    }
}
