﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
       

        public Form1()
        {
            InitializeComponent();
        }

        private void btnexercicio2_Click(object sender, EventArgs e)
        {
            ArrayList lista = new

            ArrayList() { "Ana", "Andre", "Beatriz", "Camila", "Joao", "Joana", "Otavio", "Marcelo", "Pedro", "Thais" };
          
            lista.Remove("Otavio");
            String auxiliar = "";
            foreach (String nome in lista)
            {
                auxiliar += nome + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnexercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";

            //            string saida = "";

            for (int i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i + 1}° número", "Entrada de Dados");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Valor inválido!");
                    i--;

                }
                
            }
            Array.Reverse(vetor);
            auxiliar = "";
            auxiliar = string.Join("\n", vetor);
            MessageBox.Show(auxiliar);
        }

        private void btnexercicio3_Click(object sender, EventArgs e)
        {
            Double[,] Notas = new Double[20, 3];
            String auxiliar = "";
            Double media = 0;
            String saida = "";

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota {j + 1} do aluno {i + 1}", "Entrada de Dados");
                    if (!Double.TryParse(auxiliar, out Notas[i, j]) || Notas[i, j] < 0 || Notas[i, j] > 10)
                    {
                        MessageBox.Show("Dado Inválido");
                    }else
                        {
                            media += Notas[i, j];
                        }
                        
                    }
                saida += $"Aluno: {i + 1}: media {media / 3}";
                media = 0;
                MessageBox.Show(saida);
                }

                }

        private void btnexercicio4_Click(object sender, EventArgs e)
        {
            FrmExercicio4 novoFormulario = new FrmExercicio4();
            novoFormulario.Show();
        }

        private void btnexercicio5_Click(object sender, EventArgs e)
        {
            FrmExercicio5 novoFormulario = new FrmExercicio5();
            novoFormulario.Show();
        }
    }
        }
