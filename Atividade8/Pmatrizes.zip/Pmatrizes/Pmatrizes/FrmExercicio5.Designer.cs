﻿namespace Pmatrizes
{
    partial class FrmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnverificar = new System.Windows.Forms.Button();
            this.lstbxgabarito = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnverificar
            // 
            this.btnverificar.Location = new System.Drawing.Point(202, 118);
            this.btnverificar.Name = "btnverificar";
            this.btnverificar.Size = new System.Drawing.Size(131, 107);
            this.btnverificar.TabIndex = 0;
            this.btnverificar.Text = "Verificar";
            this.btnverificar.UseVisualStyleBackColor = true;
            this.btnverificar.Click += new System.EventHandler(this.btnverificar_Click);
            // 
            // lstbxgabarito
            // 
            this.lstbxgabarito.FormattingEnabled = true;
            this.lstbxgabarito.ItemHeight = 20;
            this.lstbxgabarito.Location = new System.Drawing.Point(458, 40);
            this.lstbxgabarito.Name = "lstbxgabarito";
            this.lstbxgabarito.Size = new System.Drawing.Size(303, 404);
            this.lstbxgabarito.TabIndex = 1;
            this.lstbxgabarito.SelectedIndexChanged += new System.EventHandler(this.lstbxgabarito_SelectedIndexChanged);
            // 
            // FrmExercicio5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lstbxgabarito);
            this.Controls.Add(this.btnverificar);
            this.Name = "FrmExercicio5";
            this.Text = "FrmExercicio5";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnverificar;
        private System.Windows.Forms.ListBox lstbxgabarito;
    }
}