﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmatrizes
{
    public partial class FrmExercicio5 : Form
    {
        public FrmExercicio5()
        {
            InitializeComponent();
        }

        private void lstbxgabarito_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void btnverificar_Click(object sender, EventArgs e)
        {
            string[,] respostas = new string[9, 10];
            string[] gabarito = { "B", "D", "C", "D", "B", "C", "A", "A", "C", "A" };
            string aux;
 
            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    do
                    {
                        aux = Interaction.InputBox(
                            $"Resposta do aluno:{i + 1} questão:{j + 1}:","Entrada de dados").ToUpper();
 
                        if (string.IsNullOrEmpty(aux) || !"ABCDE".Contains(aux))
                        {
                            MessageBox.Show("Dado inválido");
                        }
 
                    } while (string.IsNullOrEmpty(aux) || !"ABCDE".Contains(aux));
 
                    respostas[i, j] = aux;
 
                    if (aux == gabarito[j])
                        lstbxgabarito.Items.Add($"O aluno:{i + 1} acertou a questão:{j + 1} era {gabarito[j]} escolheu {aux}");
                    else
                        lstbxgabarito.Items.Add($"O aluno:{i + 1} errou a questão:{j + 1} era {gabarito[j]} escolheu {aux}");
                }
            }
        }
    }   
}
