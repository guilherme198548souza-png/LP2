﻿namespace Pmatrizes
{
    partial class FrmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstbxnomes = new System.Windows.Forms.ListBox();
            this.btnexecutar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lstbxnomes
            // 
            this.lstbxnomes.ItemHeight = 20;
            this.lstbxnomes.Location = new System.Drawing.Point(478, 14);
            this.lstbxnomes.Name = "lstbxnomes";
            this.lstbxnomes.Size = new System.Drawing.Size(270, 424);
            this.lstbxnomes.TabIndex = 0;
            // 
            // btnexecutar
            // 
            this.btnexecutar.Location = new System.Drawing.Point(183, 126);
            this.btnexecutar.Name = "btnexecutar";
            this.btnexecutar.Size = new System.Drawing.Size(133, 104);
            this.btnexecutar.TabIndex = 1;
            this.btnexecutar.Text = "Executar";
            this.btnexecutar.UseVisualStyleBackColor = true;
            this.btnexecutar.Click += new System.EventHandler(this.btnexecutar_Click);
            // 
            // FrmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnexecutar);
            this.Controls.Add(this.lstbxnomes);
            this.Name = "FrmExercicio4";
            this.Text = "FrmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lstbxnomes;
        private System.Windows.Forms.Button btnexecutar;
    }
}