﻿namespace Pcalc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            lblNumero1 = new Label();
            lblNumero2 = new Label();
            txtNumero1 = new TextBox();
            txtNumero2 = new TextBox();
            txtResultado = new TextBox();
            btnAdd = new Button();
            btnSub = new Button();
            btnMult = new Button();
            btnSair = new Button();
            btnDiv = new Button();
            btnLimpar = new Button();
            errorProvider1 = new ErrorProvider(components);
            errorProvider2 = new ErrorProvider(components);
            errorProvider3 = new ErrorProvider(components);
            lblResultado = new Label();
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider3).BeginInit();
            SuspendLayout();
            // 
            // lblNumero1
            // 
            lblNumero1.AutoSize = true;
            lblNumero1.Font = new Font("Comic Sans MS", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            lblNumero1.Location = new Point(162, 95);
            lblNumero1.Name = "lblNumero1";
            lblNumero1.Size = new Size(121, 34);
            lblNumero1.TabIndex = 0;
            lblNumero1.Text = "Numero 1";
            lblNumero1.Validated += lblNumero1_Validated;
            // 
            // lblNumero2
            // 
            lblNumero2.AutoSize = true;
            lblNumero2.Font = new Font("Comic Sans MS", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            lblNumero2.Location = new Point(162, 161);
            lblNumero2.Name = "lblNumero2";
            lblNumero2.Size = new Size(125, 34);
            lblNumero2.TabIndex = 1;
            lblNumero2.Text = "Numero 2";
            // 
            // txtNumero1
            // 
            txtNumero1.Location = new Point(337, 99);
            txtNumero1.Name = "txtNumero1";
            txtNumero1.Size = new Size(266, 31);
            txtNumero1.TabIndex = 2;
            txtNumero1.Validated += txtNumero1_Validated;
            // 
            // txtNumero2
            // 
            txtNumero2.Location = new Point(337, 164);
            txtNumero2.Name = "txtNumero2";
            txtNumero2.Size = new Size(266, 31);
            txtNumero2.TabIndex = 3;
            txtNumero2.Validated += txtNumero2_Validated;
            // 
            // txtResultado
            // 
            txtResultado.BackColor = SystemColors.ScrollBar;
            txtResultado.Enabled = false;
            txtResultado.Location = new Point(337, 234);
            txtResultado.Name = "txtResultado";
            txtResultado.Size = new Size(271, 31);
            txtResultado.TabIndex = 4;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(162, 324);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(114, 76);
            btnAdd.TabIndex = 5;
            btnAdd.Text = "+";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnSub
            // 
            btnSub.Location = new Point(315, 324);
            btnSub.Name = "btnSub";
            btnSub.Size = new Size(114, 76);
            btnSub.TabIndex = 6;
            btnSub.Text = "-";
            btnSub.UseVisualStyleBackColor = true;
            btnSub.Click += btnSub_Click;
            btnSub.Validated += btnSub_Validated;
            // 
            // btnMult
            // 
            btnMult.Location = new Point(473, 324);
            btnMult.Name = "btnMult";
            btnMult.Size = new Size(114, 76);
            btnMult.TabIndex = 7;
            btnMult.Text = "*";
            btnMult.UseVisualStyleBackColor = true;
            btnMult.Click += btnMult_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(783, 225);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(114, 78);
            btnSair.TabIndex = 8;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // btnDiv
            // 
            btnDiv.Location = new Point(635, 324);
            btnDiv.Name = "btnDiv";
            btnDiv.Size = new Size(114, 76);
            btnDiv.TabIndex = 9;
            btnDiv.Text = "/";
            btnDiv.UseVisualStyleBackColor = true;
            btnDiv.Click += btnDiv_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(783, 95);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(114, 76);
            btnLimpar.TabIndex = 10;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            errorProvider2.ContainerControl = this;
            // 
            // errorProvider3
            // 
            errorProvider3.ContainerControl = this;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Font = new Font("Comic Sans MS", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            lblResultado.Location = new Point(162, 231);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(124, 34);
            lblResultado.TabIndex = 11;
            lblResultado.Text = "Resultado";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1088, 621);
            Controls.Add(lblResultado);
            Controls.Add(btnLimpar);
            Controls.Add(btnDiv);
            Controls.Add(btnSair);
            Controls.Add(btnMult);
            Controls.Add(btnSub);
            Controls.Add(btnAdd);
            Controls.Add(txtResultado);
            Controls.Add(txtNumero2);
            Controls.Add(txtNumero1);
            Controls.Add(lblNumero2);
            Controls.Add(lblNumero1);
            Name = "Form1";
            Text = "Pcalc";
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider2).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNumero1;
        private Label lblNumero2;
        private TextBox txtNumero1;
        private TextBox txtNumero2;
        private TextBox txtResultado;
        private Button btnAdd;
        private Button btnSub;
        private Button btnMult;
        private Button btnSair;
        private Button btnDiv;
        private Button btnLimpar;
        private ErrorProvider errorProvider1;
        private ErrorProvider errorProvider2;
        private ErrorProvider errorProvider3;
        private Label lblResultado;
    }
}
