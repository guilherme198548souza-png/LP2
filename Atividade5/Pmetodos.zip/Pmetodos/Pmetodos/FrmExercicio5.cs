﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class FrmExercicio5 : Form
    {
        public FrmExercicio5()
        {
            InitializeComponent();
        }

        private void FrmExercicio5_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            int valor1, valor2;

            if (!int.TryParse(txtNumero1.Text, out valor1) || !int.TryParse(txtNumero2.Text, out valor2))
            {
                MessageBox.Show("Digite apenas números inteiros válidos!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (valor1 >= valor2)
            {
                MessageBox.Show("O primeiro número deve ser menor que o segundo!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Random gerador = new Random();
            int resultado = gerador.Next(valor1, valor2 + 1);

            MessageBox.Show($"Número sorteado: {resultado}", "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
