﻿namespace Pmetodos
{
    partial class FrmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.EspacoBranco = new System.Windows.Forms.Button();
            this.ContaLetra = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(136, 61);
            this.richTextBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(200, 87);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(102, 196);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 44);
            this.button1.TabIndex = 1;
            this.button1.Text = "Corta números";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // EspacoBranco
            // 
            this.EspacoBranco.Location = new System.Drawing.Point(208, 196);
            this.EspacoBranco.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.EspacoBranco.Name = "EspacoBranco";
            this.EspacoBranco.Size = new System.Drawing.Size(72, 44);
            this.EspacoBranco.TabIndex = 2;
            this.EspacoBranco.Text = "Espaço em branco";
            this.EspacoBranco.UseVisualStyleBackColor = true;
            this.EspacoBranco.Click += new System.EventHandler(this.EspacoBranco_Click);
            // 
            // ContaLetra
            // 
            this.ContaLetra.Location = new System.Drawing.Point(304, 196);
            this.ContaLetra.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ContaLetra.Name = "ContaLetra";
            this.ContaLetra.Size = new System.Drawing.Size(72, 42);
            this.ContaLetra.TabIndex = 3;
            this.ContaLetra.Text = "Contar Letras";
            this.ContaLetra.UseVisualStyleBackColor = true;
            this.ContaLetra.Click += new System.EventHandler(this.ContaLetra_Click);
            // 
            // FrmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(533, 292);
            this.Controls.Add(this.ContaLetra);
            this.Controls.Add(this.EspacoBranco);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.richTextBox1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "FrmExercicio4";
            this.Text = "FrmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button EspacoBranco;
        private System.Windows.Forms.Button ContaLetra;
    }
}