﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if( Application.OpenForms.OfType<FrmExercicio2>().Count() > 0 )
            {
                Application.OpenForms["FrmExercicio2"].BringToFront();
            }
            else
            {
                FrmExercicio2 Frm2 = new FrmExercicio2();
                Frm2.MdiParent = this;
                Frm2.WindowState = FormWindowState.Maximized;
                Frm2.Show();
            }

                
        }

        private void exercício3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio3>().Count() > 0)
            {
                Application.OpenForms["FrmExercicio3"].BringToFront();
            }
            else
            {
                FrmExercicio3 Frm3 = new FrmExercicio3();
                Frm3.MdiParent = this;
                Frm3.WindowState = FormWindowState.Maximized;
                Frm3.Show();
            }
        }

        private void exercício4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio4>().Count() > 0)
            {
                Application.OpenForms["FrmExercicio4"].BringToFront();
            }
            else
            {
                FrmExercicio4 Frm4 = new FrmExercicio4();
                Frm4.MdiParent = this;
                Frm4.WindowState = FormWindowState.Maximized;
                Frm4.Show();
            }
        }

        private void exercício1ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void exercício5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio5>().Count() > 0)
            {
                Application.OpenForms["FrmExercicio5"].BringToFront();
            }
            else
            {
                FrmExercicio5 Frm5 = new FrmExercicio5();
                Frm5.MdiParent = this;
                Frm5.WindowState = FormWindowState.Maximized;
                Frm5.Show();
            }
        }
    }
}
