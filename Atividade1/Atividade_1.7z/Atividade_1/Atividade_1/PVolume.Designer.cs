﻿namespace Atividade_1
{
    partial class PVolume
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblRaio = new Label();
            lblAltura = new Label();
            lblVolume = new Label();
            txtRaio = new TextBox();
            txtAltura = new TextBox();
            txtVolume = new TextBox();
            btnCalcular = new Button();
            btnLimpar = new Button();
            btnFechar = new Button();
            SuspendLayout();
            // 
            // lblRaio
            // 
            lblRaio.AutoSize = true;
            lblRaio.Location = new Point(240, 119);
            lblRaio.Name = "lblRaio";
            lblRaio.Size = new Size(47, 25);
            lblRaio.TabIndex = 0;
            lblRaio.Text = "Raio";
            // 
            // lblAltura
            // 
            lblAltura.AutoSize = true;
            lblAltura.Location = new Point(240, 217);
            lblAltura.Name = "lblAltura";
            lblAltura.Size = new Size(59, 25);
            lblAltura.TabIndex = 1;
            lblAltura.Text = "Altura";
            // 
            // lblVolume
            // 
            lblVolume.AutoSize = true;
            lblVolume.Location = new Point(240, 318);
            lblVolume.Name = "lblVolume";
            lblVolume.Size = new Size(72, 25);
            lblVolume.TabIndex = 2;
            lblVolume.Text = "Volume";
            // 
            // txtRaio
            // 
            txtRaio.Location = new Point(523, 119);
            txtRaio.Name = "txtRaio";
            txtRaio.Size = new Size(150, 31);
            txtRaio.TabIndex = 3;
            txtRaio.TextChanged += txtRaio_TextChanged;
            txtRaio.Validated += txtRaio_Validated;
            // 
            // txtAltura
            // 
            txtAltura.Location = new Point(523, 217);
            txtAltura.Name = "txtAltura";
            txtAltura.Size = new Size(150, 31);
            txtAltura.TabIndex = 4;
            txtAltura.Validated += txtAltura_Validated;
            // 
            // txtVolume
            // 
            txtVolume.Enabled = false;
            txtVolume.Location = new Point(523, 315);
            txtVolume.Name = "txtVolume";
            txtVolume.Size = new Size(150, 31);
            txtVolume.TabIndex = 5;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(523, 411);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(150, 70);
            btnCalcular.TabIndex = 6;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(240, 411);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(150, 70);
            btnLimpar.TabIndex = 7;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnFechar
            // 
            btnFechar.Location = new Point(792, 411);
            btnFechar.Name = "btnFechar";
            btnFechar.Size = new Size(150, 70);
            btnFechar.TabIndex = 8;
            btnFechar.Text = "Fechar";
            btnFechar.UseVisualStyleBackColor = true;
            btnFechar.Click += btnFechar_Click;
            // 
            // PVolume
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1197, 645);
            Controls.Add(btnFechar);
            Controls.Add(btnLimpar);
            Controls.Add(btnCalcular);
            Controls.Add(txtVolume);
            Controls.Add(txtAltura);
            Controls.Add(txtRaio);
            Controls.Add(lblVolume);
            Controls.Add(lblAltura);
            Controls.Add(lblRaio);
            Name = "PVolume";
            Text = "PVolume";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblRaio;
        private Label lblAltura;
        private Label lblVolume;
        private TextBox txtRaio;
        private TextBox txtAltura;
        private TextBox txtVolume;
        private Button btnCalcular;
        private Button btnLimpar;
        private Button btnFechar;
    }
}
