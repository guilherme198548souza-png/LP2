namespace Atividade_1
{
    public partial class PVolume : Form
    {
        double raio, altura, volume;
        public PVolume()
        {
            InitializeComponent();
        }

        private void txtRaio_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtRaio.Text, out raio)
                || (raio <= 0))
            {
                MessageBox.Show("raio inv�lido");
            }
            //else if (raio<=0) 
            //{
            //    MessageBox.Show("raio deve ser maior que zero");
            //}
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtAltura.Text, out altura)
                || (altura <= 0))
            {
                MessageBox.Show("altura inv�lida");
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtRaio.Text, out raio)
                || (raio <= 0))
            {
                MessageBox.Show("raio inv�lido");
                txtRaio.Focus();
            }
            else if (!double.TryParse(txtAltura.Text, out altura)
                || (altura <= 0))
            {
                MessageBox.Show("altura inv�lida");
                txtAltura.Focus();
            }
            else
            {
                volume = Math.PI * Math.Pow(raio, 2) * altura;

                txtVolume.Text = volume.ToString("N2");

            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtRaio.Text = "";
            txtAltura.Text = String.Empty;
            txtVolume.Clear();

        }
    }
}
