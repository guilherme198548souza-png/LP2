﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Ptriangulo : Form
    {
        double ladoa, ladob,ladoc;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtladoa.Clear();
            txtladob.Clear();
            txtladoc.Clear();

        }

        private void btnCalcular_Click(object sender, EventArgs e)
       
        {
            if (double.TryParse(txtladoa.Text, out double ladoA) &&
       double.TryParse(txtladob.Text, out double ladoB) &&
       double.TryParse(txtladoc.Text, out double ladoC))
            {
                // Verifica se os lados formam um triângulo válido
                if (ladoA + ladoB > ladoC && ladoA + ladoC > ladoB && ladoB + ladoC > ladoA)
                {
                    if (ladoA == ladoB && ladoB == ladoC)
                    {
                        MessageBox.Show("O triângulo é EQUILÁTERO.", "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else if (ladoA == ladoB || ladoA == ladoC || ladoB == ladoC)
                    {
                        MessageBox.Show("O triângulo é ISÓSCELES.", "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("O triângulo é ESCALENO.", "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Os lados não formam um triângulo válido.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Digite valores numéricos válidos.", "Entrada inválida", MessageBoxButtons.OK, MessageBoxIcon.Error);
                btnCalcular.Focus();

            }
        }
        

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?",
                                "Saída", MessageBoxButtons.YesNo
                                , MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        public Ptriangulo()
        {
            InitializeComponent();
        }

        private void Ptriangulo_Load(object sender, EventArgs e)
        {

        }
    }
}
